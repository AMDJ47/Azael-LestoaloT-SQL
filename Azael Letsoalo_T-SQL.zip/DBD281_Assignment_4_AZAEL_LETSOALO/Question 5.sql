-- Question5 --
USE AdventureWorks2017
GO
CREATE VIEW vwStoreSales
AS
SELECT 
Sales.Customer.CustomerID,
Sales.Store.Name,
YEAR(Sales.SalesOrderHeader.OrderDate) AS YEAR,
CONVERT(DECIMAL(20,2),SUM(Sales.SalesOrderHeader.Freight+Sales.SalesOrderHeader.TaxAmt+Sales.SalesOrderHeader.SubTotal)) AS YEARSALES
FROM Sales.Customer 
INNER JOIN Sales.Store 
ON Sales.Customer.StoreID = Sales.Store.BusinessEntityID
INNER JOIN Sales.SalesOrderHeader 
ON SalesOrderHeader.CustomerID = Sales.Customer.CustomerID
GROUP BY SC.CustomerID, S.S.Name, YEAR(SOH.OrderDate)
HAVING SUM(SOH.Freight+SOH.TaxAmt+SOH.SubTotal) > 100000
ORDER BY CustomerID ASC,YEAR DESC