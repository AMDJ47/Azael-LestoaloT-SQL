--Question 3--
 SELECT Person.Person.Title,Person.Person.FirstName,Person.Person.LastName,
 CASE WHEN PersonType= 'SC' THEN 'Store Contact'
  WHEN PersonType='EM' THEN 'Employee'
 WHEN PersonType='VC' THEN 'Vendor Contact'
 WHEN PersonType='IN' THEN ' Individual Customer'
 WHEN PersonType='SP' THEN 'Sales Person'
 ELSE 'General Contact' END AS 'Person Type'
 FROM Person.Person