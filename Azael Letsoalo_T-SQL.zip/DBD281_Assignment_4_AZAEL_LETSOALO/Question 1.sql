--Question 1--
USE AdventureWorks2017
SELECT HumanResources.Employee.BusinessEntityID AS 'BusEntID',
HumanResources.Employee.NationalIDNumber AS 'NationalID',
Person.Person.LastName,
Person.Person.FirstName,
HumanResources.Department.Name AS 'Department',
HumanResources.Employee.JobTitle
FROM HumanResources.Employee
Where OrganizationLevel =1