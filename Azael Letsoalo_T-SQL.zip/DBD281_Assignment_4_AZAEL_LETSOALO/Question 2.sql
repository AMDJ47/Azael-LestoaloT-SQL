--Question 2--
WITH CTE_TotalPurchases(TotalDue,ShipMethodID)
 AS
 (SELECT ShipMethodID,SUM(TotalDue)
 FROM Purchasing.PurchaseOrderHeader
 GROUP BY ShipMethodID),

 CTE_TotalSales(ShipMethodID,TotalDue)
 AS 
 (SELECT ShipMethodID, SUM(TotalDue)
 FROM Sales.SalesOrderHeader
 GROUP BY ShipMethodID)

 SELECT Purchasing.ShipMethod.AK_ShipMethod_Name
 FROM Purchasing.ShipMethod
 INNER JOIN CTE_TotalPurchases
 ON Purchasing.ShipMethod.ShipMethodID = CTE_TotalPurchases.ShipMethodID
 INNER JOIN CTE_TotalSales
 ON Purchasing.ShipMethod.ShipMethodID = CTE_TotalSales.ShipMethodID