--Question 4--
DECLARE Product707 CURSOR
    FOR select ProductID,ListPrice;
	OPEN Product707
	FETCH NEXT FROM cursor INTO ListPrice
	HILE @@FETCH_STATUS = 0  
    BEGIN
        FETCH NEXT FROM Product707;  
    END;
	CLOSE cursor_name;
	DEALLOCATE cursor_name;
